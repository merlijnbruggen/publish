import numpy as np
import numpy.ma as ma
import scipy
import deeptime as dtime

from src.mps.utils import extract_valid_segments


def get_count_matrix(labels: np.ndarray | ma.MaskedArray | list, min_size: int = 2, sparse_return: bool = True,
                     lag: int = 1):
    """
    Computes a count matrix from valid segments in a time series.

    Parameters:
    - labels (numpy.ndarray or numpy.ma.MaskedArray or list): Input time series data with labels. If list it's a list of labels.
      It can be a 1D array or a 2D array with labels.
    - min_size (int, optional): Minimum size of valid segments (default is 2).
    - sparse_return (bool, optional): If True, the result is sparse.
    - lag (int, optional): The lag parameter for the count matrix computation (default is 1).

    Returns:
    numpy.ndarray or scipy.sparse.csr_matrix: Count matrix computed from valid segments in the input time series.

    Example:

    >>> labels1 = np.array([1, 2, 2, 3, 3, 3, 2, 1])
    >>> get_count_matrix(labels1, min_size=2, sparse_return=False, lag=1)
    array([[0., 0., 0., 0.],
           [0., 0., 1., 0.],
           [0., 1., 1., 1.],
           [0., 0., 1., 2.]])

    >>> labels2 = np.array([1, 2, 2, 3, np.nan, 3, 3, 2, 1])
    >>> get_count_matrix(labels2, min_size=2, sparse_return=False, lag=1)
    array([[0., 0., 0., 0.],
           [0., 0., 1., 0.],
           [0., 1., 1., 1.],
           [0., 0., 1., 1.]])

    >>> masked_labels3 = np.ma.array([1, 2, 2, 3, np.ma.masked, 3, 3, 2, 1], mask=[0, 0, 0, 0, 1, 0, 0, 0, 0])
    >>> get_count_matrix(masked_labels3, min_size=2, sparse_return=False, lag=1)
    array([[0., 0., 0., 0.],
           [0., 0., 1., 0.],
           [0., 1., 1., 1.],
           [0., 0., 1., 1.]])

    >>> labels_lag4 = np.array([0, 1, 0, 2, 3, np.nan, 3, 3, 2, 1])
    >>> get_count_matrix(labels_lag4, min_size=2, sparse_return=False, lag=2)
    array([[1., 0., 0., 1.],
           [0., 0., 1., 0.],
           [0., 0., 0., 0.],
           [0., 1., 1., 0.]])

    >>> labels_list = [
    ...     np.array([1, 2, 1]),
    ...     np.array([0, 1, 0])
    ... ]
    >>> get_count_matrix(labels_list, min_size=2, sparse_return=False, lag=1)
    array([[0., 1., 0.],
           [1., 0., 1.],
           [0., 1., 0.]])
    """

    # Step 1: Find valid segment boundaries
    # Check if labels is a list
    if isinstance(labels, list):
        # Initialize an empty list to store valid segments from each element in the list
        traj_list = []
        # Iterate over each element in the list
        for label in labels:
            # Extract valid segments for the current element
            traj_list.extend(extract_valid_segments(label, min_size=min_size, dtype=int))
    else:
        # Extract valid segments from the input labels
        traj_list = extract_valid_segments(labels, min_size=min_size, dtype=int)

    # Step 2: Compute the count matrix using dtime.markov.tools.estimation
    count_matrix = dtime.markov.tools.estimation.count_matrix(traj_list,
                                                              lag=lag,
                                                              sliding=True,
                                                              sparse_return=sparse_return)
    return count_matrix


def get_transition_matrix(labels: np.ndarray | np.ma.MaskedArray,
                          min_size: int = 2,
                          lag: int = 1,
                          sparse_return: bool = True,
                          directed: bool = False,
                          return_largest_connected: bool = False) -> scipy.sparse.csr_matrix | tuple[
    scipy.sparse.csr_matrix, np.ndarray]:
    """
    Calculates the transition matrix from a time series of labels.

    Note: directed=True is stricter than directed=False.
    If directed=True, it is not enough to have a directional connection between A and B: A->B in order to be in a
    connected set.

    Args:
        labels (numpy.ndarray or numpy.ma.MaskedArray): Input time series data with labels.
        min_size (int, optional): Minimum size of valid segments (default is 2).
        lag (int, optional): The lag parameter for the count matrix computation (default is 1).
        sparse_return (bool, optional): If True, the result is a sparse matrix; otherwise, it's a dense array (default is True).
        directed (bool, optional): If True, treats the transitions as directed; otherwise, it treats them as undirected (default is False).
        return_largest_connected (bool, optional): If True, returns the transition matrix and the largest connected set (default is False).

    Returns:
        scipy.sparse.csr_matrix or tuple[scipy.sparse.csr_matrix, np.ndarray]: Transition matrix computed from valid segments in the input time series.
        If return_largest_connected is True, also returns the largest connected set.

    Example:
    >>> labels = np.array([1, 2, 2, 3, np.nan, 3, 3, 2, 1])
    >>> get_transition_matrix(labels, min_size=2, lag=1, sparse_return=False, directed=False)
    array([[0.        , 1.        , 0.        ],
           [0.33333333, 0.33333333, 0.33333333],
           [0.        , 0.5       , 0.5       ]])

    >>> labels = np.array([1, 2, 3, 1])
    >>> get_transition_matrix(labels, min_size=2, lag=1, sparse_return=False, directed=False)
    array([[0., 1., 0.],
           [0., 0., 1.],
           [1., 0., 0.]])

    >>> labels = np.array([1, 2, 3, 2])
    >>> get_transition_matrix(labels, min_size=2, lag=1, sparse_return=False, directed=False)
    array([[0., 1., 0.],
           [0., 0., 1.],
           [0., 1., 0.]])

    >>> labels = np.array([1, 2, 3, 2])
    >>> out = get_transition_matrix(labels, min_size=2, lag=1, sparse_return=False, directed=True,
    ...       return_largest_connected=True)
    >>> out[0]
    array([[0., 1.],
           [1., 0.]])
    >>> out[1]
    array([2, 3])
    """
    # Step 1: Create the count matrix using the get_count_matrix function
    count_matrix = get_count_matrix(labels, min_size=min_size, sparse_return=sparse_return, lag=lag)

    # Step 2: Get the largest connected set
    count_matrix_largest_connected = dtime.markov.tools.estimation.largest_connected_submatrix(count_matrix,
                                                                                               directed=directed)

    # Step 3: Calculate the transition matrix using dtime.markov.tools.estimation
    out = dtime.markov.tools.estimation.transition_matrix(count_matrix_largest_connected,
                                                          reversible=False,
                                                          return_statdist=False)
    if return_largest_connected:
        largest_connected_states = dtime.markov.tools.estimation.largest_connected_set(count_matrix,
                                                                                       directed=directed)
        return out, largest_connected_states

    return out


def get_entropy_rate(transition_matrix: scipy.sparse.csr_matrix,
                     return_stationary: bool = False,
                     mode: str = 'fallback'
                     ) \
        -> float or tuple[float, np.ndarray]:
    """
    Calculate the entropy of a Markov chain represented by a transition matrix.

    Args:
        transition_matrix (scipy.sparse.csr_matrix): The transition matrix of the Markov chain.
        return_stationary: Also return stationary dist.
        mode (str, optional, default='fallback'): Used to calculate the stationary distribution.
            Determines whether the method first tries backward iteration and then
            eigenvector estimation (`'fallback'`) or it uses backward iteration only (`'backward'`) or it uses
            eigenvector estimation only (`'eigenvector'`). Taken from deeptime function docs.
    Returns:
        float or tuple[float, np.ndarray]: The entropy of the Markov chain. If return_stationary is True, also returns
        the stationary distribution.

    Examples:
    >>> dense_transition_matrix = np.array([[0.5, 0.5], [0.3, 0.7]])
    >>> sparse_transition_matrix = scipy.sparse.csr_matrix(dense_transition_matrix)
    >>> entropy_result = get_entropy_rate(sparse_transition_matrix)
    """

    # Calculate the stationary distribution
    mu = get_stationary_distribution(transition_matrix, mode=mode)

    # Convert stationary distribution to a sparse diagonal matrix
    mu_as_sparse_matrix = scipy.sparse.diags(mu)

    # Create a copy of the transition matrix and replace non-zero entries with their logarithms
    logTM = transition_matrix.copy()
    logTM.data = np.log(logTM.data)

    # Compute the entropy using the stationary distribution and logarithmic transition matrix
    entropy = -mu_as_sparse_matrix.dot(transition_matrix.multiply(logTM)).sum()

    if return_stationary:
        return entropy, mu
    else:
        return entropy


def get_stationary_distribution(transition_matrix: scipy.sparse.csr_matrix | np.ndarray,
                                mode: str = 'fallback'):
    """
    Compute the stationary distribution of a given transition matrix using Deeptime library.

    Uses a "fast computation of the stationary vector using backward iteration" (from deeptime
    stationary_distribution_from_backward_iteration function).

    Args:
        transition_matrix (scipy.sparse.csr_matrix or np.ndarray): The transition matrix.
        mode (str, optional, default='fallback'): Determines whether the method first tries backward iteration and then
            eigenvector estimation (`'fallback'`) or it uses backward iteration only (`'backward'`) or it uses
            eigenvector estimation only (`'eigenvector'`). Taken from deeptime function docs.
    Returns:
        np.ndarray: Vector of stationary probabilities.

    Examples:
        >>> from scipy.sparse import csr_matrix
        >>> transition_matrix = csr_matrix([[0.1, 0.5, 0.4], [0.2, 0.3, 0.5], [0.7, 0.2, 0.1]])
        >>> get_stationary_distribution(transition_matrix)
        array([0.33333333, 0.33333333, 0.33333333])

        >>> T = np.array([[0.9, 0.1], [0.8, 0.2]])
        >>> mu = get_stationary_distribution(T)
        >>> mu
        array([0.88888889, 0.11111111])

        >>> T = np.array([[0.9, 0.1], [0.8, 0.2]])
        >>> mu = get_stationary_distribution(T, mode="eigenvector")
        >>> mu
        array([0.88888889, 0.11111111])
    """
    return dtime.markov.tools.analysis.stationary_distribution(transition_matrix, mode=mode)


def get_reversible_transition_matrix(transition_matrix: scipy.sparse.csr_matrix,
                                     mode: str = 'fallback') -> scipy.sparse.csr_matrix:
    """
    Calculates the reversible transition matrix from a given transition matrix.

    Args:
        transition_matrix (csr_matrix): The input transition matrix.
        mode (str, optional, default='fallback'): Used to calculate the stationary distribution.
            Determines whether the method first tries backward iteration and then
            eigenvector estimation (`'fallback'`) or it uses backward iteration only (`'backward'`) or it uses
            eigenvector estimation only (`'eigenvector'`). Taken from deeptime function docs.
    Returns:
        csr_matrix: The reversible transition matrix.

    Note:
        The reversible transition matrix (R) is computed using the formula:
        R = (P + P_hat) / 2, where P_hat is a modified version of the transpose of P.

    Example:
        >>> transition_matrix = np.array([[0.1, 0.5, 0.4], [0.2, 0.3, 0.5], [0.7, 0.2, 0.1]])
        >>> get_reversible_transition_matrix(transition_matrix)
        array([[0.1 , 0.35, 0.55],
               [0.35, 0.3 , 0.35],
               [0.55, 0.35, 0.1 ]])

        >>> P = scipy.sparse.csr_matrix([[0.9, 0.1, 0.0], [0.5, 0.0, 0.5], [0.0, 0.1, 0.9]])
        >>> get_reversible_transition_matrix(P.toarray())
        array([[0.9, 0.1, 0. ],
               [0.5, 0. , 0.5],
               [0. , 0.1, 0.9]])
    """
    # Step 1: Calculate the stationary distribution of the input matrix P
    stationary_probs = get_stationary_distribution(transition_matrix, mode=mode)

    # Step 2: Create a diagonal matrix with the reciprocals of the stationary probabilities
    inv_probs_diagonal = scipy.sparse.diags(1 / stationary_probs)

    # Step 3: Create a modified version of the transpose of P
    transition_matrix_hat = inv_probs_diagonal @ transition_matrix.transpose() @ scipy.sparse.diags(stationary_probs)

    # Step 4: Calculate the reversible transition matrix R
    reversible_transition_matrix = (transition_matrix + transition_matrix_hat) / 2

    return reversible_transition_matrix


def get_eigenspectrum(transition_matrix: np.ndarray | scipy.sparse.csr_matrix,
                      k: int | None = None,
                      which: str = 'LR',
                      sort_by: str = 'R') -> tuple[np.ndarray, np.ndarray]:
    """
    Compute the eigenvalues and corresponding eigenvectors of a transition matrix.

    Note: Like in the deeptime library, the left eigenvectors are computed!

    Parameters:
    - transition_matrix (np.ndarray or scipy.sparse.csr_matrix): The transition matrix.
    - k (int, optional): The number of eigenvalues and eigenvectors to compute. If None, compute all.
    - which (str, optional): Eigenvalues and eigenvectors are computed based on this criteria. Default is 'LR'
                            (largest real). Scipy default is 'LM' (largest magnitude).
                            Only has an effect if sparse.linalg.eigs is used, which is the case when the TM is sparse
                            and larger than 10x10.
    - sort_by (str, optional): Sorting criteria for eigenvalues. 'R' for real part, 'M' for magnitude. Default is 'R'.

    Returns:
    - Tuple[np.ndarray, np.ndarray]: Eigenvalues and corresponding eigenvectors.

    Examples:
    >>> from scipy.sparse import csr_matrix
    >>> # Example 1: Compute eigenvalues and eigenvectors for the entire matrix
    >>> matrix = csr_matrix([[0.9, 0.1, 0.0], [0.5, 0.0, 0.5], [0.0, 0.1, 0.9]])
    >>> eigenvalues, eigenvectors = get_eigenspectrum(matrix, k=None)
    >>> eigenvalues
    array([ 1. +0.j,  0.9+0.j, -0.1+0.j])

    >>> # Example 2: Compute eigenvalues and eigenvectors for the entire matrix
    >>> matrix = np.array([[0.9, 0.1, 0.0], [0.5, 0.0, 0.5], [0.0, 0.1, 0.9]])
    >>> eigenvalues, eigenvectors = get_eigenspectrum(matrix, k=None)
    >>> eigenvalues
    array([ 1. +0.j,  0.9+0.j, -0.1+0.j])

    >>> # Example 3: Sparse large identity matrix
    >>> matrix = scipy.sparse.eye(100, format='csr')
    >>> eigenvalues, eigenvectors = get_eigenspectrum(matrix, k=3)
    >>> eigenvalues
    array([1.+0.j, 1.+0.j, 1.+0.j])
    """
    if k is None:
        k = transition_matrix.shape[0]
    elif not isinstance(k, int) or k <= 0:
        raise ValueError("k must be a positive integer.")
    if k > transition_matrix.shape[0]:
        raise ValueError("k cannot be larger than the number of states in the transition matrix.")

    issparse = scipy.sparse.issparse(transition_matrix)

    # Compute eigenvalues based on matrix size
    if issparse and transition_matrix.shape[0] > 10:
        eigvals, eigvecs = scipy.sparse.linalg.eigs(transition_matrix.T, k=k, which=which, return_eigenvectors=True)
    else:
        if issparse:
            transition_matrix = transition_matrix.toarray()
        eigvals, eigvecs = scipy.linalg.eig(transition_matrix, left=True, right=False)
    if sort_by == 'R':
        sorted_indices = np.argsort(eigvals.real)[::-1][:k]
    elif sort_by == 'M':
        sorted_indices = np.argsort(np.abs(eigvals))[::-1][:k]
    else:
        raise ValueError(f"sort_by must be either R (real) or M (magnitude). Got {sort_by=}.")
    return eigvals[sorted_indices], eigvecs[:, sorted_indices]


def get_timescales(transition_matrix: np.ndarray | scipy.sparse.csr_matrix,
                   lag: int,
                   dt: float = 1.0,
                   k: int | None = None,
                   remove_first: bool = True,
                   which: str = 'LR',
                   sort_by: str = 'R'
                   ) -> np.ndarray:
    """
    Compute relaxation timescales from the transition matrix.

    Note: To get the same timescales as with deeptime.markov.tools.analysis.timescales(..) you have to use which='LM' and
    sort_by='M'.

    Args:
        transition_matrix (np.ndarray or scipy.sparse.csr_matrix): Transition matrix.
        lag (int): Time lag used for calculation of transition matrix.
        dt (float, optional): Real time step corresponding to smallest step of the label trajectory (default is 1).
        k (int or None, optional): Number of timescales to compute. If None, computes all available timescales (default is None).
        remove_first (bool, optional): Whether to remove the first eigenvalue before calculating timescales (default is False).
        which (str, optional): Eigenvalues and eigenvectors are computed based on this criteria. Default is 'LR'
                            (largest real). Scipy default is 'LM' (largest magnitude).
                            Only has an effect if sparse.linalg.eigs is used, which is the case when the TM is sparse
                            and larger than 10x10.
        sort_by (str, optional): Sorting criteria for eigenvalues. 'R' for real part, 'M' for magnitude. Default is 'R'.

    Returns:
        numpy.ndarray: Array of relaxation timescales. The first entry is nan, as it is infinite.

    Note:
        The function calculates the relaxation timescales from the eigenvalues of the transition matrix P.
        If P is a sparse matrix, it uses the Lanczos algorithm for eigenvalue computation.

    Examples:
        >>> from scipy.sparse import csr_matrix
        >>> P = csr_matrix([[0.9, 0.1, 0.0], [0.5, 0.0, 0.5], [0.0, 0.1, 0.9]])
        >>> R = get_reversible_transition_matrix(P)
        >>> get_timescales(R, lag=1, dt=1, k=None)
        array([9.49122158, 0.43429448])

        >>> get_timescales(R, lag=1, dt=1, k=2, remove_first=False)
        array([       nan, 9.49122158])
    """
    if k is None:
        k = transition_matrix.shape[0]
    elif not isinstance(k, int) or k <= 0:
        raise ValueError("k must be a positive integer.")
    if k > transition_matrix.shape[0]:
        raise ValueError("k cannot be larger than the number of states in the transition matrix.")

    eigvals, _ = get_eigenspectrum(transition_matrix, k=k, which=which, sort_by=sort_by)

    # Set eigenvals close to 1 and close to 0 to nan.
    eigvals[np.abs(eigvals - 1) < 1e-12] = np.nan
    eigvals[np.abs(eigvals) < 1e-12] = np.nan

    # Calculate relaxation timescales
    timescales = -(lag * dt) / np.log(np.abs(eigvals))

    # Remove first eigenvalue which is nan if remove_first=True.
    if remove_first:
        return timescales[1:]
    else:
        return timescales


def label_indices_of_largest_connected(labels: ma.masked_array, largest_connected: np.ndarray) -> ma.masked_array:
    """Return the timeseries of indices of the labels as listed in the largest connected set.

    Parameters:
    - labels (numpy.ma.masked_array): A masked array representing the time series of labels.
    - largest_connected (numpy.ndarray): An array containing labels in the largest connected set.

    Returns:
    - numpy.ma.masked_array: A masked array representing the time series of indices of labels
      as listed in the largest connected set.

    Examples:
    1. For a masked array of labels with a largest connected set:
        >>> labels = ma.masked_array([1, 2, np.nan, 4, 5], mask=[False, False, True, False, False])
        >>> largest_connected_set = np.array([4, 5])
        >>> label_indices_of_largest_connected(labels, largest_connected_set)
        masked_array(data=[--, --, --, 0, 1],
                     mask=[ True,  True,  True, False, False],
               fill_value=999999)
    """
    labels_indices = ma.zeros(labels.shape, dtype=int)
    labels_indices.mask = labels.mask
    for time, (label, is_masked) in enumerate(zip(labels, labels.mask)):
        if not is_masked:
            if label in largest_connected:
                labels_indices[time] = np.where(label == largest_connected)[0][0]
            else:
                pass
                labels_indices.mask[time] = [True]
    return labels_indices
