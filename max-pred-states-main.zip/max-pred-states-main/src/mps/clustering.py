import numpy as np
import numpy.ma as ma
from sklearn.cluster import MiniBatchKMeans, KMeans
import faiss


def cluster_data(data: np.ndarray, n_clusters: int, algorithm: str = 'minibatchkmeans',
                 random_state: int or None = None,
                 batch_size: int or None = None,
                 return_centers: bool = False) -> tuple:
    """
    Perform clustering on the input data using either KMeans or MiniBatchKMeans.

    Args:
        data (np.ndarray): The input data array of shape (N, D).
        n_clusters (int): The number of clusters to form.
        algorithm (str): The clustering algorithm to use, either 'kmeans' or 'minibatchkmeans' (default: 'kmeans').
        random_state (int or None): The random seed for reproducibility (default: None).
        batch_size (int or None): The number of samples to use for each mini-batch (only applicable for 'minibatchkmeans').
        return_centers (bool): If True, return cluster centers along with labels (default: False).

    Returns:
        tuple: A tuple containing:
        np.ndarray: The transformed discrete time series.
        np.ndarray: The cluster centers (only if return_centers is True).
        model: The kmeans model.

    Examples:
    >>> data1 = np.array([[1, 2, 3], [4, np.nan, 6], [7, 8, 9], [10, 11, 12]])
    >>> n_clusters1 = 2
    >>> result1 = cluster_data(data1, n_clusters1, algorithm='kmeans', random_state=42)
    >>> cluster_assignments1, model1 = result1

    >>> data2 = np.array([[1, 2, 3], [4, 5, 6], [7, np.nan, 9], [10, 11, 12]])
    >>> n_clusters2 = 3
    >>> result2 = cluster_data(data2, n_clusters2, algorithm='minibatchkmeans', batch_size=3, return_centers=True)
    >>> cluster_assignments2, cluster_centers2, model2 = result2
    """
    # Convert data to masked array if it contains missing values
    data = ma.masked_invalid(data)

    # Perform clustering based on the selected algorithm
    if algorithm == 'kmeans':
        model = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=3)
    elif algorithm == 'minibatchkmeans':
        if batch_size is None:
            batch_size = 3 * n_clusters
        model = MiniBatchKMeans(n_clusters=n_clusters, random_state=random_state,
                                batch_size=batch_size, n_init=3)
    else:
        raise ValueError(
            "Invalid algorithm. Choose either 'kmeans' or 'minibatchkmeans'")

    # Fit the model and get cluster assignments and centers
    labels = ma.zeros(data.shape[0], dtype=int)
    labels.mask = np.any(data.mask, axis=1)
    labels[~labels.mask] = model.fit_predict(ma.compress_rows(data))
    cluster_centers = model.cluster_centers_

    if return_centers:
        return labels, cluster_centers, model
    else:
        return labels, model


def cluster_data_faiss(data: np.ndarray, n_clusters: int,
                       random_state: int or None = None,
                       return_centers: bool = False,
                       verbose: bool = False,
                       niter: int = 25) -> tuple:
    """
    Perform clustering on the input data using faiss KMeans.

    Args:
        data (np.ndarray): The input data array of shape (N, D).
        n_clusters (int): The number of clusters to form.
        random_state (int or None): The random seed for reproducibility (default: None).
        return_centers (bool): If True, return cluster centers along with labels (default: False).
        verbose (bool): If True, print progress messages (default: False).
        niter (int): The number of iterations to run the k-means algorithm (default: 25).

    Returns:
        tuple: A tuple containing:
        np.ndarray: The cluster assignments.
        np.ndarray: The cluster centers (only if return_centers is True).
        model: The faiss model.

    Examples:
    >>> data1 = np.array([[1, 2, 3], [4, np.nan, 6], [7, 8, 9], [10, 11, 12]])
    >>> n_clusters1 = 2
    >>> result1 = cluster_data(data1, n_clusters1, algorithm='kmeans', random_state=42)
    >>> cluster_assignments1, model1 = result1

    >>> data2 = np.array([[1, 2, 3], [4, 5, 6], [7, np.nan, 9], [10, 11, 12]])
    >>> n_clusters2 = 3
    >>> result2 = cluster_data(data2, n_clusters2, algorithm='minibatchkmeans', batch_size=3, return_centers=True)
    >>> cluster_assignments2, cluster_centers2, model2 = result2
    """
    # Convert data to masked array if it contains missing values
    data = ma.masked_invalid(data)

    n_clusters = int(n_clusters)

    # get faiss.Kmeans model:
    if random_state is not None:
        model = faiss.Kmeans(data.shape[1], n_clusters, niter=niter, verbose=verbose, seed=int(random_state))
    else:
        model = faiss.Kmeans(data.shape[1], n_clusters, niter=niter, verbose=verbose)

    # Fit the model and get cluster assignments and centers
    labels = ma.zeros(data.shape[0], dtype=int)
    labels.mask = np.any(data.mask, axis=1)
    model.train(ma.compress_rows(data))
    _, labels_out = model.index.search(ma.compress_rows(data), 1)
    labels[~labels.mask] = labels_out[:, 0]

    cluster_centers = model.centroids

    if return_centers:
        return labels, cluster_centers, model
    else:
        return labels, model


def reconstruct(labels: np.ndarray | ma.masked_array,
                cluster_centers: np.ndarray) -> ma.masked_array:
    """
    Reconstructs data from cluster labels and cluster centers.

    Parameters:
        labels (numpy.ndarray or numpy.ma.masked_array): Array of cluster labels.
        cluster_centers (numpy.ndarray): Array of cluster centers.

    Returns:
        numpy.ma.masked_array: Reconstructed data.

    Examples:
    >>> labels = np.array([0, 1, 0, 1, 2])
    >>> cluster_centers = np.array([[0.1, 0.2], [0.3, 0.4], [0.5, 0.6]])
    >>> reconstruction = reconstruct(labels, cluster_centers)
    >>> reconstruction
    masked_array(
      data=[[0.1, 0.2],
            [0.3, 0.4],
            [0.1, 0.2],
            [0.3, 0.4],
            [0.5, 0.6]],
      mask=[[False, False],
            [False, False],
            [False, False],
            [False, False],
            [False, False]],
      fill_value=1e+20)

    >>> labels = ma.array([0, 1, np.nan, 1, 2], mask=[False, False, True, False, False])
    >>> cluster_centers = np.array([[0.1, 0.2], [0.3, 0.4], [0.5, 0.6]])
    >>> reconstruction = reconstruct(labels, cluster_centers)
    >>> reconstruction
    masked_array(
      data=[[0.1, 0.2],
            [0.3, 0.4],
            [--, --],
            [0.3, 0.4],
            [0.5, 0.6]],
      mask=[[False, False],
            [False, False],
            [ True,  True],
            [False, False],
            [False, False]],
      fill_value=1e+20)
    """

    labels = ma.masked_invalid(labels)

    reconstruction = ma.zeros((labels.size, cluster_centers.shape[1]))

    mask = labels.mask
    reconstruction.mask = np.repeat(mask[:, np.newaxis], repeats=cluster_centers.shape[1], axis=1)

    recon_compressed = cluster_centers[labels.compressed().astype(int)]
    reconstruction[~mask] = recon_compressed

    return reconstruction
