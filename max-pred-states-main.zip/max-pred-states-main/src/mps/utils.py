import numpy as np
import numpy.ma as ma


def find_valid_segment_boundaries(time_series: np.ndarray | np.ma.MaskedArray, min_size: int = 50) -> np.ndarray:
    """
    Finds boundaries of valid segments in a time series with missing data.

    Parameters:
    - time_series (numpy.ndarray or numpy.ma.MaskedArray): Input time series data.
    - min_size (int, optional): Minimum size of valid segments (default is 50).

    Returns:
    numpy.ndarray: Array containing boundaries of valid segments.
    The output is of shape (number_of_valid_sections, 2), where the last two elements in each row
    represent the start and (1 + end) indices of the valid segments.

    Example:
    >>> time_series = np.array([1, 2, np.nan, 4, 5, 6, np.nan, 8, 9])
    >>> find_valid_segment_boundaries(time_series, min_size=1)
    array([[0, 2],
           [3, 6],
           [7, 9]])

    >>> out = find_valid_segment_boundaries(time_series, min_size=1)
    >>> time_series[out[0, 0]: out[0, 1]]
    array([1., 2.])

    >>> time_series = np.array([[1, 2, 3], [4, 5, 6], [np.nan, np.nan, np.nan], [10, 11, 12]])
    >>> find_valid_segment_boundaries(time_series, min_size=1)
    array([[0, 2],
           [3, 4]])
    """

    # Check if min_size is a positive integer
    if not isinstance(min_size, int) or min_size <= 0:
        raise ValueError("min_size must be a positive integer greater than 0.")

    # Step 1: Ensure time_series is a masked array
    if not np.ma.isMaskedArray(time_series):
        time_series = ma.masked_invalid(time_series)

    # Step 2: Create a boolean mask indicating where data is present.
    # If some data is nan for some time-steps, the whole sub-array corresponding to that time step is naned.
    if len(time_series.shape) > 1:
        mask = ~np.any(time_series.mask, axis=1)
    else:
        mask = ~time_series.mask

    # Step 3: Find boundaries of segments with missing data
    boundary_indices = np.where(np.abs(np.diff(np.concatenate([[False], mask, [False]]))))[0]

    # Step 4: Reshape the boundaries into pairs
    segment_boundaries = boundary_indices.reshape(-1, 2)

    # Step 5: Filter segments based on minimum size
    valid_segment_boundaries = np.array([seg for seg in segment_boundaries if seg[1] - seg[0] >= min_size])

    return valid_segment_boundaries


def extract_valid_segments(time_series: np.ndarray | np.ma.MaskedArray,
                           min_size: int = 50,
                           dtype: type = float,
                           return_segment_boundaries: bool = False) -> list[np.ndarray] | tuple[list[np.ndarray], np.ndarray]:
    """
    Extracts valid segments from a time series with missing data.

    Parameters:
    - time_series (numpy.ndarray or numpy.ma.MaskedArray): Input time series data.
    - min_size (int, optional): Minimum size of valid segments (default is 50).
    - dtype (type, optional): Data type to cast the extracted valid segments.
      Default is float, but can be specified as int or other valid NumPy dtype.
    - return_segment_boundaries (bool, optional): If true also return the valid_segment_boundaries.
    Returns:
    list[np.ndarray]: List of numpy arrays containing valid segments.

    Example:
    >>> time_series = np.array([1, 2, np.nan, 4, 5, 6, np.nan, 8, 9])
    >>> extract_valid_segments(time_series, min_size=1)
    [array([1., 2.]), array([4., 5., 6.]), array([8., 9.])]

    >>> masked_array = np.ma.array([1, 2, np.ma.masked, 4, 5, 6, np.ma.masked, 8, 9], mask=[0, 0, 1, 0, 0, 0, 1, 0, 0])
    >>> extract_valid_segments(masked_array, min_size=1)
    [array([1., 2.]), array([4., 5., 6.]), array([8., 9.])]

    >>> time_series_int = np.array([1, 2, np.nan, 4, 5, 6, np.nan, 8, 9])
    >>> extract_valid_segments(time_series_int, min_size=1, dtype=int)
    [array([1, 2]), array([4, 5, 6]), array([8, 9])]
    """

    # Step 1: Find valid segment boundaries
    valid_segment_boundaries = find_valid_segment_boundaries(time_series, min_size)

    # Step 2: Extract valid segments and convert them to numpy arrays with specified dtype
    valid_segments = [np.asarray(time_series[start:end].data, dtype=dtype) for start, end in valid_segment_boundaries]

    if return_segment_boundaries:
        return valid_segments, valid_segment_boundaries
    else:
        return valid_segments
