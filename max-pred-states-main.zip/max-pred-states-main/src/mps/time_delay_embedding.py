import numbers
import numpy as np
import numpy.ma as ma


def time_delay_embedding(data: np.ndarray, delay: int, masked_array: bool = False) -> np.ndarray:
    """Create a time-delay embedding of a N times D numpy data array.

    Args:
        data (np.ndarray): The input data array of shape (N, D).
        delay (int): The time delay (lag) for creating the embedding.
        masked_array (bool, optional): If True, return the time-delayed data as a masked array.
                                       Default is False.

    Returns:
        np.ndarray or np.ma.MaskedArray: The time-delay embedded data array of shape (N - delay, D * (delay + 1)).

    Examples:
    >>> data1 = np.array([[1, 2, 3], [4, np.nan, 6], [7, 8, 9], [10, 11, 12]])  # shape (4, 3)
    >>> delay1 = 1
    >>> time_delay_embedding(data1, delay1)
    array([[ 1.,  2.,  3.,  4., nan,  6.],
           [ 4., nan,  6.,  7.,  8.,  9.],
           [ 7.,  8.,  9., 10., 11., 12.]])

    >>> data2 = np.array([[1, 2, 3], [4, np.nan, 6], [7, 8, 9], [10, 11, 12]])
    >>> delay2 = 1
    >>> time_delay_embedding(data2, delay2, masked_array=True)
    masked_array(
      data=[[1.0, 2.0, 3.0, 4.0, --, 6.0],
            [4.0, --, 6.0, 7.0, 8.0, 9.0],
            [7.0, 8.0, 9.0, 10.0, 11.0, 12.0]],
      mask=[[False, False, False, False,  True, False],
            [False,  True, False, False, False, False],
            [False, False, False, False, False, False]],
      fill_value=1e+20)

    >>> data3 = np.array([[1, 2, 3], [4, np.nan, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]])  # shape (5, 3)
    >>> delay3 = 2
    >>> time_delay_embedding(data3, delay3)
    array([[ 1.,  2.,  3.,  4., nan,  6.,  7.,  8.,  9.],
           [ 4., nan,  6.,  7.,  8.,  9., 10., 11., 12.],
           [ 7.,  8.,  9., 10., 11., 12., 13., 14., 15.]])
    """
    # Check if the input data is a numpy array
    if not isinstance(data, np.ndarray):
        raise TypeError("Input data must be a numpy array")

    # Check if delay is a non-negative integer
    if not isinstance(delay, numbers.Integral) or delay < 0:
        raise ValueError("Delay must be a non-negative integer")

    # Check if data is 1d, then extend axis
    if len(data.shape) == 1:
        data = data[:, np.newaxis]

    if delay == 0:
        embedded_data = data
    else:
        # Create the time-delay embedding
        embedded_data = np.hstack([np.roll(data, -i, axis=0) for i in range(0, delay + 1)])

        # Remove the rows with NaN values introduced by rolling
        embedded_data = embedded_data[:-delay]

    if masked_array:
        # Create a masked array with NaN values masked
        embedded_data = ma.masked_invalid(embedded_data)

    return embedded_data


def reverse_time_delay_embedding(embedded_data: np.ndarray,
                                 delay: int,
                                 masked_array: bool = True) -> np.ndarray:
    """Unroll time-delay embedded data into a specified shape.

    Args:
        embedded_data (np.ndarray): The time-delay embedded data array.
        delay (int): The time delay (lag) used for creating the embedding.
        masked_array (bool, optional): If True, return the unrolled data as a masked array with NaN values for masked entries.
                               Default is False.
    Returns:
        np.ndarray: The unrolled data array of shape (N - delay, D, delay + 1).

    Examples:
    >>> embedded_data1 = np.array([[1., 2., 3., 4., np.nan, 6.],
    ...                            [4., np.nan, 6., 7., 8., 9.],
    ...                            [7., 8., 9., 10., 11., 12.]])
    >>> delay1 = 1
    >>> reverse_time_delay_embedding(embedded_data1, delay1, masked_array=False)
    array([[ 1.,  2.,  3.],
           [ 4., nan,  6.],
           [ 7.,  8.,  9.],
           [10., 11., 12.]])

    >>> embedded_data2 = ma.array([[1., 2., 3., 4., ma.masked, 6.],
    ...                            [4., ma.masked, 6., 7., 8., 9.],
    ...                            [7., 8., 9., 10., 11., 12.]])
    >>> delay2 = 1
    >>> reverse_time_delay_embedding(embedded_data2, delay2)
    masked_array(
      data=[[1.0, 2.0, 3.0],
            [4.0, --, 6.0],
            [7.0, 8.0, 9.0],
            [10.0, 11.0, 12.0]],
      mask=[[False, False, False],
            [False,  True, False],
            [False, False, False],
            [False, False, False]],
      fill_value=1e+20)

    >>> embedded_data3 = np.array([[1., 2., 3., 4., np.nan, 6., 7., 8., 9.],
    ...                            [4., np.nan, 6., 7., 8., 9., 10., 11., 12.],
    ...                            [7., 8., 9., 10., 11., 12., 13., 14., 15.]])
    >>> delay3 = 2
    >>> reverse_time_delay_embedding(embedded_data3, delay3, masked_array=False)
    array([[ 1.,  2.,  3.],
           [ 4., nan,  6.],
           [ 7.,  8.,  9.],
           [10., 11., 12.],
           [13., 14., 15.]])

    >>> embedded_data4 = np.array([[1., 2., 3., 4., np.nan, 6., 7., 8., 9.]])
    >>> delay4 = 2
    >>> reverse_time_delay_embedding(embedded_data4, delay4, masked_array=False)
    array([[ 1.,  2.,  3.],
           [ 4., nan,  6.],
           [ 7.,  8.,  9.]])

    >>> embedded_data5 = np.array([[1., 2., 3., 4., np.nan, 6., 7., 8., 9.]])
    >>> delay4 = 0
    >>> reverse_time_delay_embedding(embedded_data4, delay4, masked_array=False)
    array([[ 1.,  2.,  3.,  4., nan,  6.,  7.,  8.,  9.]])
    """
    embedded_data = ma.masked_invalid(embedded_data)

    k = delay + 1  # embedding dimension
    time_steps, state_dim_w_delay = embedded_data.shape
    original_state_dim = int(state_dim_w_delay / k)
    original_shape = (time_steps + delay, original_state_dim)
    # Check if the input data is a numpy array
    if not isinstance(embedded_data, np.ndarray):
        raise TypeError("Input data must be a numpy array")

    # Check if delay is a non-negative integer
    if not isinstance(delay, int) or delay < 0:
        raise ValueError("Delay must be a non-negative integer")

    original_data = ma.zeros(original_shape)
    original_data[:k, :] = embedded_data[0, :].reshape((k, embedded_data.shape[1] // k))
    original_data[k:, :] = embedded_data[1:, - embedded_data.shape[1] // k:]

    if not masked_array:
        # Turn all masked values to NaN
        original_data = original_data.filled(np.nan)

    return original_data


def reverse_time_delay_embedding_averaged(embedded_data: np.ndarray | ma.masked_array,
                                          delay: int,
                                          masked_array: bool = True,
                                          return_individuals: bool = True) -> np.ndarray | ma.masked_array:
    """
    Reverse Time Delay Embedding Averaged.

    Like reverse_time_delay_embedding but actually averages all occurences of a time-step over all timesteps.
    This is useful when you reconstruct the time-delayed timeseries from cluster centers and then want a smooth output.

    Parameters:
        embedded_data (numpy.ndarray or numpy.ma.masked_array): Embedded data, shape (time_steps_w_delay, state_dim_w_delay).
        delay (int): The delay value for time delay embedding.
        masked_array (bool, optional): If True, return masked array, else return numpy array with NaNs for invalid values.
        return_individuals (bool, optional): If True, return individual unrolled data.

    Returns:
        numpy.ndarray or numpy.ma.masked_array: Averaged unrolled data or masked array.
            If return_individuals is True, returns a tuple of averaged unrolled data and individual unrolled data.

    Examples:
    >>> embedded_data1 = np.array([[1., 2., 3., 4., np.nan, 6.],
    ...                            [4., np.nan, 6., 7., 8., 9.],
    ...                            [7., 8., 9., 10., 11., 12.]])
    >>> delay1 = 1
    >>> reverse_time_delay_embedding(embedded_data1, delay1, masked_array=False)
    array([[ 1.,  2.,  3.],
           [ 4., nan,  6.],
           [ 7.,  8.,  9.],
           [10., 11., 12.]])

    >>> embedded_data2 = ma.array([[1., 2., 3., 4., ma.masked, 6.],
    ...                            [4., ma.masked, 6., 7., 8., 9.],
    ...                            [7., 8., 9., 10., 11., 12.]])
    >>> delay2 = 1
    >>> reverse_time_delay_embedding(embedded_data2, delay2)
    masked_array(
      data=[[1.0, 2.0, 3.0],
            [4.0, --, 6.0],
            [7.0, 8.0, 9.0],
            [10.0, 11.0, 12.0]],
      mask=[[False, False, False],
            [False,  True, False],
            [False, False, False],
            [False, False, False]],
      fill_value=1e+20)

    >>> embedded_data3 = np.array([[1., 2., 3., 4., np.nan, 6., 7., 8., 9.],
    ...                            [4., np.nan, 6., 7., 8., 9., 10., 11., 12.],
    ...                            [7., 8., 9., 10., 11., 12., 13., 14., 15.]])
    >>> delay3 = 2
    >>> reverse_time_delay_embedding(embedded_data3, delay3, masked_array=False)
    array([[ 1.,  2.,  3.],
           [ 4., nan,  6.],
           [ 7.,  8.,  9.],
           [10., 11., 12.],
           [13., 14., 15.]])

    >>> embedded_data4 = np.array([[1., 2., 3., 4., np.nan, 6., 7., 8., 9.]])
    >>> delay4 = 2
    >>> reverse_time_delay_embedding(embedded_data4, delay4, masked_array=False)
    array([[ 1.,  2.,  3.],
           [ 4., nan,  6.],
           [ 7.,  8.,  9.]])
    """
    if isinstance(embedded_data, ma.masked_array):
        embedded_data = ma.filled(embedded_data, np.nan)  # Turn to numpy array if possible.

    k = delay + 1  # embedding dimension
    time_steps_w_delay, state_dim_w_delay = embedded_data.shape
    original_state_dim = int(state_dim_w_delay / k)
    original_shape = (time_steps_w_delay + delay, original_state_dim)

    # unroleld time series
    out_data = np.zeros(original_shape)

    # Save the individual unrolls if return_individual is true
    if return_individuals:
        individuals_unrolled = []

    for i in range(original_shape[0]):
        data_per_time_step = []

        min_val = np.max((0, i - time_steps_w_delay + 1))
        max_val = np.min((k - 1, i))

        for j in range(min_val, max_val + 1):
            data_per_time_step.append(embedded_data[i - j, j * original_state_dim: (j + 1) * original_state_dim])

        data_per_time_step = np.vstack(data_per_time_step)  # shape: occurrences x original_state_dim
        out_data[i, :] = np.nanmean(data_per_time_step, axis=0)

        if return_individuals:
            individuals_unrolled.append(data_per_time_step)

    if masked_array:
        out_data = ma.masked_invalid(out_data)

    if return_individuals:
        return out_data, individuals_unrolled
    else:
        return out_data
