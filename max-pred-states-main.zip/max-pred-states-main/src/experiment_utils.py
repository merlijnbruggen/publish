import subprocess

def get_git_status():
    """
    Retrieve Git status including branch, commit hash, and the latest commit message.

    Returns:
        str: A string containing branch name, commit hash, and the latest commit message.

    Raises:
        subprocess.CalledProcessError: If the Git commands fail to execute.

    Example:
        >>> get_git_status()
        'Branch: main, Commit: abcdef123456, Commit Message: Add new feature'
    """
    try:
        branch = subprocess.check_output(['git', 'rev-parse', '--abbrev-ref', 'HEAD']).decode('utf-8').strip()
        commit = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode('utf-8').strip()
        commit_message = subprocess.check_output(['git', 'log', '-1', '--pretty=%B']).decode('utf-8').strip()
        return f"Branch: {branch}, Commit: {commit}, Commit Message: {commit_message}"
    except subprocess.CalledProcessError:
        return "Unable to retrieve Git status."
