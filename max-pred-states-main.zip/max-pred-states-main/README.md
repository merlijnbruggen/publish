# max-pred-states
Maximally predictive states scheme combining time-delay-embeddings with entropy-rate calculations. 

# Info
Boils down to a refactoring of the original maximally predictive states repository (https://github.com/AntonioCCosta/maximally_predictive_states). 

Paper: https://doi.org/10.1063/5.0129398


## Useful bash commands

#### Update conda `environment.yml` file after having installed / updated packages

```bash
conda env export --from-history > environment.yml
```

#### For the exact environment versions use this to update `environment_exact.yml` file after having installed / updated packages

```bash
conda env export > environment_exact.yml
```

#### Install `max-pred-states` environment from `environment.yml` file

```bash
conda env create -f environment.yml
```

#### Update the environment based on a new `environment.yml` file

```bash
conda env update --file environment.yml --prune
```

#### Activate `max-pred-states` environment

```bash
conda activate max-pred-states
```


## Run code

Add the `max-pred-states` directory to path in order to find the modules specified
in `src`.
Run the following when importing packages.

```python
import sys

sys.path.append(<absolute path to max-pred-states>)
```

For example if your Python-file / Notebook is located
in `max-pred-states/some-directory/[pythonfile.py or notebook.ipynb]` then run:

```python
import sys
import os

repo_path = os.path.abspath(os.path.join(os.getcwd(), '..'))
sys.path.append(repo_path)
```

## Git

Discard local changes in **tracked files**
```bash
git checkout -- .
```

Remove all **untracked files**
```bash
git clean -df
```

# Faiss for fast Kmeans clustering
The library [faiss](https://github.com/facebookresearch/faiss) offers extremely fast kmeans clustering on CPUs and GPUs. 
For it to properly work, you have to use the Intel MKL backend for numpy. 
When instead the openBLAS library is used the resulting calculations might be much slower. 
See these links: 
- https://github.com/facebookresearch/faiss/issues/201
- https://github.com/facebookresearch/faiss/wiki/Troubleshooting#slow-brute-force-search-with-openblas
- https://github.com/facebookresearch/faiss/issues/53
- 
And this link to check if your numpy uses MKL or openBLAS:
- https://www.capitalone.com/tech/machine-learning/accelerating-python-with-hardware-optimized-computing/
