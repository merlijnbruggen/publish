# Maximally Predictive States Notebooks

Here, the two example notebooks for the Double-Well and Lorenz System are reproduced with the functions implemented here. 

[Link to notebooks](https://github.com/AntonioCCosta/maximally_predictive_states/tree/main/ExamplePipeline)